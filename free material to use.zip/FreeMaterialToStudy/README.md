# Free Material To Study — Android starter project

A native Android app starter built with Kotlin and Jetpack Compose. Includes:
- Modern mobile-first home screen and resource cards
- Search and subject filters
- Saved/bookmarked resources for the current app session
- Dark mode toggle saved on the device
- Subtle Compose animations and Material 3 styling
- Sample resource data you can replace with verified open materials

## Build an installable APK (Android Studio)

1. Install **Android Studio** from https://developer.android.com/studio on a computer.
2. Unzip this project folder.
3. In Android Studio, choose **Open** and select the `FreeMaterialToStudy` folder.
4. Allow Gradle sync to finish. Install the Android SDK Platform 35 if prompted.
5. To test on a phone, enable Developer options and USB debugging, connect the phone, then press **Run**.
6. To create an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. When the build completes, click **Locate**. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
8. Transfer the APK to your Android phone and open it. You may need to allow installation from that file manager/source.

## Notes

- This project is source code, not a precompiled APK.
- Requires Android Studio/Android SDK and a JDK compatible with the Android Gradle Plugin (JDK 17 is recommended).
- Demo resource cards do not contain real PDFs. Add links to resources that are openly licensed or that you have permission to distribute.
- The starter keeps bookmarks in memory while the app runs; dark mode preference is persisted. If you want persistent bookmarks, wire them to DataStore or Room.
- Application ID: `com.freematerialtostudy.app`
