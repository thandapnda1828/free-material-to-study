package com.freematerialtostudy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Indigo = Color(0xFF6558E8)
private val Teal = Color(0xFF23B7A4)

data class StudyResource(
    val title: String,
    val subject: String,
    val kind: String,
    val detail: String,
    val icon: ImageVector,
    val tint: Color
)

private val resources = listOf(
    StudyResource("Algebra Essentials", "Mathematics", "PDF NOTES", "12 pages · Beginner", Icons.Default.Calculate, Color(0xFFE9E6FF)),
    StudyResource("Motion & Forces", "Physics", "QUICK GUIDE", "8 min read · Class 10", Icons.Default.Bolt, Color(0xFFFFE9D8)),
    StudyResource("Cell Biology", "Biology", "REVISION NOTES", "16 pages · Class 9–10", Icons.Default.Spa, Color(0xFFDDF7ED)),
    StudyResource("English Grammar", "English", "PRACTICE SET", "25 questions · All levels", Icons.Default.MenuBook, Color(0xFFFFE3EC)),
    StudyResource("Chemical Reactions", "Chemistry", "SUMMARY", "10 pages · Class 10", Icons.Default.Science, Color(0xFFDFF0FF)),
    StudyResource("World History", "Social Studies", "STUDY NOTES", "14 pages · Beginner", Icons.Default.Public, Color(0xFFFFF0C9))
)

@Composable
fun StudyTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFFB9B1FF),
        secondary = Color(0xFF65D9C7),
        background = Color(0xFF10111A),
        surface = Color(0xFF1A1C28),
        surfaceVariant = Color(0xFF252737),
        onBackground = Color(0xFFF4F3FC),
        onSurface = Color(0xFFF4F3FC)
    ) else lightColorScheme(
        primary = Indigo,
        secondary = Teal,
        background = Color(0xFFF7F7FC),
        surface = Color.White,
        surfaceVariant = Color(0xFFEFEEFA),
        onBackground = Color(0xFF1B1B2A),
        onSurface = Color(0xFF1B1B2A)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("study_prefs", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark_mode", false)) }
            StudyTheme(dark) {
                StudyHome(
                    dark = dark,
                    onToggleTheme = {
                        dark = !dark
                        prefs.edit().putBoolean("dark_mode", dark).apply()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyHome(dark: Boolean, onToggleTheme: () -> Unit) {
    var search by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf("All") }
    var currentTab by remember { mutableStateOf("Home") }
    var saved by remember { mutableStateOf(setOf<String>()) }
    var selectedResource by remember { mutableStateOf<StudyResource?>(null) }
    val subjects = listOf("All", "Mathematics", "Physics", "Biology", "English", "Chemistry")
    val filtered = resources.filter {
        (selectedSubject == "All" || it.subject == selectedSubject) &&
            (it.title.contains(search, true) || it.subject.contains(search, true)) &&
            (currentTab != "Saved" || saved.contains(it.title))
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                listOf(
                    Triple("Home", Icons.Default.Home, "Home"),
                    Triple("Explore", Icons.Default.Explore, "Explore"),
                    Triple("Saved", Icons.Default.Bookmark, "Saved"),
                    Triple("Profile", Icons.Default.Person, "Profile")
                ).forEach { (label, icon, tab) ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        if (selectedResource != null) {
            ResourceDetails(
                resource = selectedResource!!,
                isSaved = saved.contains(selectedResource!!.title),
                onBack = { selectedResource = null },
                onSave = {
                    val title = selectedResource!!.title
                    saved = if (saved.contains(title)) saved - title else saved + title
                },
                modifier = Modifier.padding(padding)
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("YOUR LEARNING SPACE", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Text("Study smarter.", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
                            Text("Find your next breakthrough.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f), fontSize = 14.sp)
                        }
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(46.dp).clickable { onToggleTheme() }) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Toggle dark mode", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
                item {
                    Surface(shape = RoundedCornerShape(26.dp), color = Indigo, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Surface(color = Color.White.copy(alpha = .16f), shape = RoundedCornerShape(30.dp)) {
                                Text("  ✨  YOUR NEXT CHAPTER STARTS HERE  ", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp))
                            }
                            Text("Knowledge is\none tap away.", color = Color.White, fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Explore notes, guides and practice resources made for curious minds.", color = Color.White.copy(alpha = .86f), fontSize = 13.sp, lineHeight = 19.sp)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.AutoStories, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Text("${resources.size} starter resources", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search notes, subjects...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = { if (search.isNotEmpty()) IconButton(onClick = { search = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear search") } },
                        shape = RoundedCornerShape(18.dp),
                        singleLine = true
                    )
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (currentTab == "Saved") "Your saved materials" else "Browse subjects", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        if (currentTab == "Saved") Text("${saved.size} saved", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                    }
                }
                item {
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(subjects) { subject ->
                            FilterChip(
                                selected = selectedSubject == subject,
                                onClick = { selectedSubject = subject },
                                label = { Text(subject) },
                                leadingIcon = if (selectedSubject == subject) ({ Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }) else null
                            )
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text(if (currentTab == "Saved") "BOOKMARKS" else "PICK UP SOMETHING NEW", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .58f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${filtered.size} items", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                if (filtered.isEmpty()) {
                    item {
                        Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AutoStories, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
                            Spacer(Modifier.height(10.dp))
                            Text(if (currentTab == "Saved") "Nothing saved yet" else "No materials found", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Try another search or subject.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .6f))
                        }
                    }
                } else {
                    items(filtered, key = { it.title }) { resource ->
                        ResourceCard(
                            resource = resource,
                            saved = saved.contains(resource.title),
                            onClick = { selectedResource = resource },
                            onSave = { saved = if (saved.contains(resource.title)) saved - resource.title else saved + resource.title }
                        )
                    }
                }
                item {
                    Text("Free Material To Study  •  Learn at your own pace", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .45f), fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                }
            }
        }
    }
}

@Composable
fun ResourceCard(resource: StudyResource, saved: Boolean, onClick: () -> Unit, onSave: () -> Unit) {
    val elevation by animateDpAsState(if (saved) 5.dp else 1.dp, label = "cardElevation")
    Surface(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = elevation,
        tonalElevation = 1.dp
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(shape = RoundedCornerShape(17.dp), color = resource.tint, modifier = Modifier.size(58.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(resource.icon, contentDescription = null, tint = Color(0xFF34304E), modifier = Modifier.size(27.dp))
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(resource.kind, color = MaterialTheme.colorScheme.primary, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                Text(resource.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${resource.subject}  ·  ${resource.detail}", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f), fontSize = 11.sp, maxLines = 2)
            }
            IconButton(onClick = onSave) {
                Icon(if (saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = if (saved) "Remove bookmark" else "Save resource", tint = if (saved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
            }
        }
    }
}

@Composable
fun ResourceDetails(resource: StudyResource, isSaved: Boolean, onBack: () -> Unit, onSave: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Resource overview", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Surface(shape = RoundedCornerShape(28.dp), color = resource.tint, modifier = Modifier.fillMaxWidth().height(180.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(resource.icon, contentDescription = null, tint = Color(0xFF34304E), modifier = Modifier.size(72.dp))
            }
        }
        Text(resource.subject.uppercase(), color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text(resource.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text(resource.detail, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
        Text("This is a sample resource card for the app starter. Add your own verified, openly licensed PDFs, notes, and links before sharing the app publicly.", lineHeight = 23.sp)
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Icon(if (isSaved) Icons.Default.BookmarkRemove else Icons.Default.BookmarkAdd, null)
            Spacer(Modifier.width(8.dp))
            Text(if (isSaved) "Remove from saved" else "Save for later")
        }
        Text("Tip: Only add materials you have permission to distribute.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .55f), fontSize = 12.sp)
    }
}
